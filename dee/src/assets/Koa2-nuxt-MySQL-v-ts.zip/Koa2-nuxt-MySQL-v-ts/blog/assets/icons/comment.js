/* eslint-disable */
var icon = require('vue-svgicon')
icon.register({
  'comment': {
    width: 200,
    height: 200,
    viewBox: '0 0 1024 1024',
    data: '<defs/><path pid="0" d="M711.1 292.5V164.3H89v494.2h128v128.3l397.6-.5 73.5 73.4 73.5-73 173.4.1V292.5H711.1zM135 612.5V210.3h530.1v82.2H217v320h-82zm754 128.3l-146.3-.1-54.5 54.1-54.6-54.5-370.6.5V338.5h626v402.3z" _fill="#8a8a8a"/><path pid="1" d="M336.1 516.6h96v46h-96zm191.9 0h96v46h-96zm194.7 0h96v46h-96z" _fill="#8a8a8a"/>'
  }
})
