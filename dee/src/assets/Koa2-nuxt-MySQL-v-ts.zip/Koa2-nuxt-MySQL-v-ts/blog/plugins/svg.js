/**
 * Author：brand
 * Creation Time：2019-03-14 20:22
 * Email：brandhuang@qq.com
 */
import Vue from 'vue'
import SvgIcon from 'vue-svgicon'

// Default tag name is 'svgicon'
Vue.use(SvgIcon, {
  tagName: 'svgicon'
})
