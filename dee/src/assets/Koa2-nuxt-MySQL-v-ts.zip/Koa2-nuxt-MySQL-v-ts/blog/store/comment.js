export const state = () => ({

  // 评论列表
  list: {},


})

export const mutations = {
  // 获取评论列表
  GET_COMMENT_SUCCESS(state, data) {
    state.list = data
  },
}
