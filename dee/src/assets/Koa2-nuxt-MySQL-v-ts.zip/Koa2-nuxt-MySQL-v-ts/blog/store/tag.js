export const state = () => ({

  // 标签列表
  list: {},


})

export const mutations = {
  // 获取文章列表
  GET_TAG_SUCCESS(state, data) {
    state.list = data
  },
}
