export const state = () => ({

  // 分类列表
  list: {},


})

export const mutations = {
  // 获取文章列表
  GET_CATEGORY_SUCCESS(state, data) {
    state.list = data
  },
}
