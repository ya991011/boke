import React, {FC} from "react";

const Dashborad: FC = () => {
    return (
        <div>
            首页看板，将来可能添加一些数据展示～，暂时空置
        </div>
    )
}

export default Dashborad