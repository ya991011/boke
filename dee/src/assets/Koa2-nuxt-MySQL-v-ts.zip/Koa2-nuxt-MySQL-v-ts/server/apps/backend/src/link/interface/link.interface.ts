/**
 * Author：Brand
 * Email：brandhuang@qq.com
 * CreateTime: 2020/2/10 21:03
 * Description:
 */

export interface LinkInterface {
    id: number;
    siteName: string;
    siteUrl: string;
    status: number,
    cdate: number;
}