/**
 * Author：Brand
 * Email：brandhuang@qq.com
 * CreateTime: 2020/2/12 17:09
 * Description:
 */

export class CategoryCreateDto {
    categoryname: string;
    categorydesc: string;
}