/**
 * Author：Brand
 * Email：brandhuang@qq.com
 * CreateTime: 2020/2/20 14:38
 * Description:
 */

export interface TagInterface {

}